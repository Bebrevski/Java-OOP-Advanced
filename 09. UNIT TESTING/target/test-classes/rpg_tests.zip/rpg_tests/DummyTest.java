package rpg_tests;

import org.junit.Before;
import org.junit.Test;
import rpg_lab.Axe;
import rpg_lab.Dummy;

import static org.junit.Assert.*;

public class DummyTest {

    private Dummy dummy;
    private Axe axe;

    @Before
    public void setUp() {
        
    }

    @Test
    public void getHealth() {
    }

    @Test
    public void takeAttack() {
    }

    @Test
    public void giveExperience() {
    }

    @Test
    public void isDead() {
    }
}